
<!DOCTYPE html>

<?php
// koneksi
include_once("config_login.php");
 
?>
<html lang="en">
  <head>
    <title>Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="css/css_dashboard.css">
  </head>
  <body>
    <div class="wrapper">
      <nav class="navbar navbar-default">
        <div class="navbar-header">
          <a class="navbar-brand" href="#">Dashboard</a>
        </div>
      </nav>
      <aside class="sidebar">
        <menu>
          <ul class="menu-content">
            <li><a href="dashboard.php"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#"><i class="fa fa-cube"></i> <span> Data User</span></a></li>
            <li><a href="dashboard_pekerjaan.php"><i class="fa fa-cube"></i> <span>Data Pekerjaan</span></a></li>
            <li><a href="logout.php"><span>Keluar</span></a></li>
          </ul>
        </menu>
      </aside>
      <section class="content">
        <div class="inner">
          <p>
            <div>
            <a href="dashboard_user.php">@Refresh Halaman</a><br/><br/>
            <div class="tabel">
              <div class="table-responsive">
                <table class="table align-items-center ">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nama</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Username</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ID Pegawai</th>
                      <th class="text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php 
                  while($user_data = mysqli_fetch_array($result)) {         
                      echo "<tr>";
                      echo "<td>".$user_data['nama']."</td>";
                      echo "<td>".$user_data['username']."</td>";
                      echo "<td>".$user_data['id_pegawai']."</td>";    
                      echo "<td><a href='edit.php?id=$user_data[id]'>Edit</a> | <a href='delete.php?id=$user_data[id]'>Delete</a></td></tr>";        
                  }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
            </div>
          </p>
        </div>
      </section>
    </div>
    </body>
</html>