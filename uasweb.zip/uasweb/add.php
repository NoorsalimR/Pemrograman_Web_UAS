<html>
<head>
	<title>Add Users</title>
</head>
 
<body>
	<a href="dashboard.php">Kembali Ke Halaman Dashboard</a>
	<br/><br/>
 
	<form action="add.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Nama</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr> 
				<td>Pekerjaan</td>
				<td><input type="text" name="pekerjaan"></td>
			</tr>
			<tr> 
				<td>Status</td>
				<td><input type="text" name="status"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Tambah"></td>
			</tr>
		</table>
	</form>
	
	<?php
 
	// mengecek If dari yang disubmit, masukkan data formulir ke tabel pengguna
	if(isset($_POST['Submit'])) {
		$nama = $_POST['nama'];
		$pekerjaan = $_POST['pekerjaan'];
		$status = $_POST['status'];
		
		// Masukkan file koneksi database
		include_once("config.php");
				
		// Masukkan data pengguna ke dalam tabel
		$result = mysqli_query($mysqli, "INSERT INTO users(nama,pekerjaan,status) VALUES('$nama','$pekerjaan','$status')");
		
		// Tampilkan pesan saat pengguna menambahkan
		echo "User added successfully. <a href='index.php'>View Users</a>";
	}
	?>
</body>
</html>