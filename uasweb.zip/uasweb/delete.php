<?php
// koneksi
include_once("config.php");
 
// mendapatkan id untuk menghapus user
$id = $_GET['id'];
 
// menghapus baris pengguna dari tabel berdasarkan id yang diberikan
$result = mysqli_query($mysqli, "DELETE FROM users WHERE id=$id");
 
// setelah menghapus redirect ke Beranda, maka daftar pengguna terbaru akan ditampilkan.
header("Location:dashboard.php");
?>