<?php
//error_reporting(0);
session_start();
include('config_login.php');
error_reporting(0);
if(isset($_POST['signup']))
{
  $nama=$_POST['nama'];
  $username=$_POST['username']; 
  $id_pegawai=$_POST['id_pegawai'];
  $password=md5($_POST['password']); 
  $sql="INSERT INTO  tblusers(nama,username,id_pegawai,password) VALUES(:namaa,:usernamea,:id_pegawaia,:passworda)";
  $query = $dbh->prepare($sql);
  $query->bindParam(':namaa',$nama,PDO::PARAM_STR);
  $query->bindParam(':usernamea',$username,PDO::PARAM_STR);
  $query->bindParam(':id_pegawaia',$id_pegawai,PDO::PARAM_STR);
  $query->bindParam(':passworda',$password,PDO::PARAM_STR);
  $query->execute();
  $lastInsertId = $dbh->lastInsertId();
  if($lastInsertId)
  {
    echo "<script>alert('Pendaftaran Berhasil');</script>";
  }
  else 
  {
    echo "<script>alert('Ada yang salah & Coba lagi!');</script>";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Daftar</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
</head>
<body>
  <br /><br />
  <div class="container">
   <nav class="navbar navbar-inverse">
    <div class="container-fluid">
     <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Login</a>
      <a class="navbar-brand" href="#">Daftar</a>
    </div>
  </div>
</nav>
<br />
<h2 align="center">Please Register</h2>
<br/>
<form method="post" name="signup" onSubmit="return valid();">
 <div class="form-group">
   <label>FULNAME</label>
   <input type="text" class="form-control" name="nama" placeholder="Nama*" required="required">
 </div>
 <div class="form-group">
   <label>ID Pegawai</label>
   <input type="text" class="form-control" name="id_pegawai" placeholder="ID Pegawai*" maxlength="10" required="required">
 </div>
 <div class="form-group">
   <label>Username</label>
   <input type="text" class="form-control" name="username" id="emailid" placeholder="Username*" required="required">
 </div>
 <div class="form-group">
   <label>ENTER PASSWORD</label>
   <input type="password" class="form-control" name="password" placeholder="Password*" required="required">
 </div>
 <div class="form-group">
   <label>Konfirmasi PASSWORD</label>
   <input type="password" class="form-control" name="confirmpassword" placeholder="Masukkan Ulang Password*" required="required">
 </div>
 <div class="form-group">
   <button class="btn btn-primary" type="submit" name="signup" id="submit">Daftar</button>
 </div>
</form>
</div>
</body>
</html>