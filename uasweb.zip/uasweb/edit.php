<?php
// koneksi
include_once("config.php");
 
// memeriksa apakah formulir dikirimkan untuk pembaruan user, lalu arahkan kembali ke beranda setelah pembaruan
if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	
	$nama=$_POST['nama'];
	$status=$_POST['status'];
	$pekerjaan=$_POST['pekerjaan'];
		
	// update data user 
	$result = mysqli_query($mysqli, "UPDATE users SET nama='$nama',pekerjaan='$pekerjaan',status='$status' WHERE id=$id");
	
	// mengarahkan ulang ke beranda untuk menampilkan pengguna yang diperbarui dalam daftar
	header("Location: index.php");
}
?>
<?php
// Tampilkan data pengguna yang dipilih berdasarkan id

$id = $_GET['id'];
 
// Fetech data user atau Ambil data pengguna berdasarkan id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");
 
while($user_data = mysqli_fetch_array($result))
{
	$nama = $user_data['nama'];
	$pekerjaan = $user_data['pekerjaan'];
	$status = $user_data['status'];
}
?>
<html>
<head>	
	<title>Edit User Data</title>
</head>
 
<body>
	<a href="dashboard.php">Kembali Ke Halaman Dashboard</a>
	<br/><br/>
	
	<form name="update_user" method="post" action="edit.php">
		<table border="0">
			<tr> 
				<td>Nama</td>
				<td><input type="text" name="nama" value=<?php echo $nama;?>></td>
			</tr>
			<tr> 
				<td>Pekerjaan</td>
				<td><input type="text" name="pekerjaan" value=<?php echo $pekerjaan;?>></td>
			</tr>
			<tr> 
				<td>Status</td>
				<td><input type="text" name="status" value=<?php echo $status;?>></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update Data"></td>
			</tr>
		</table>
	</form>
</body>
</html>